#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <string>

class Account {
protected:
    int accountNumber;
    std::string holderName;
    double balance;

public:
    Account(int accNo, const std::string& name, double initialBalance);

    virtual ~Account() = default;

    virtual std::string getAccountType() const = 0;

    virtual void withdraw(double amount);

    void deposit(double amount);

    virtual void displayDetails() const;

    void saveAccount() const;

    void logTransaction(const std::string& type, double amount) const;

    int getAccountNumber() const;

    double getBalance() const;
};

#endif