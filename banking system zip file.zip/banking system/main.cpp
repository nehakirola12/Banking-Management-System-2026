#include <iostream>
#include <vector>
#include <memory>
#include <limits>
#include <string>
#include "Account.h"
#include "SavingsAccount.h"
#include "CurrentAccount.h"

using namespace std;

Account* findAccount(vector<unique_ptr<Account>>& accounts, int accNo) {
    for (auto& account : accounts) {
        if (account->getAccountNumber() == accNo) {
            return account.get();
        }
    }

    return nullptr;
}

void createAccount(vector<unique_ptr<Account>>& accounts, bool savings) {
    int accNo;
    string name;
    double initialBalance;

    cout << "Enter account number: ";
    if (!(cin >> accNo)) {
        throw invalid_argument("Invalid account number.");
    }

    if (findAccount(accounts, accNo) != nullptr) {
        throw invalid_argument("This account number already exists.");
    }

    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    cout << "Enter account holder name: ";
    getline(cin, name);

    cout << "Enter initial balance: Rs. ";
    if (!(cin >> initialBalance)) {
        throw invalid_argument("Invalid initial balance.");
    }

    unique_ptr<Account> account;

    if (savings) {
        account = make_unique<SavingsAccount>(
            accNo, name, initialBalance
        );
    } else {
        account = make_unique<CurrentAccount>(
            accNo, name, initialBalance
        );
    }

    account->saveAccount();

    accounts.push_back(move(account));

    cout << "Account created successfully!\n";
}

int main() {
    vector<unique_ptr<Account>> accounts;
    int choice;

    do {
        cout << "\n===== BANKING MANAGEMENT SYSTEM =====\n";
        cout << "1. Create Savings Account\n";
        cout << "2. Create Current Account\n";
        cout << "3. Deposit Money\n";
        cout << "4. Withdraw Money\n";
        cout << "5. Display Account Details\n";
        cout << "6. Display All Accounts\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";

        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Please enter a valid number.\n";
            continue;
        }

        try {
            int accNo;
            double amount;
            Account* account;

            switch (choice) {
                case 1:
                    createAccount(accounts, true);
                    break;

                case 2:
                    createAccount(accounts, false);
                    break;

                case 3:
                    cout << "Enter account number: ";
                    if (!(cin >> accNo)) {
                        throw invalid_argument("Invalid account number.");
                    }

                    account = findAccount(accounts, accNo);

                    if (account == nullptr) {
                        cout << "Account not found!\n";
                        break;
                    }

                    cout << "Enter deposit amount: Rs. ";
                    if (!(cin >> amount)) {
                        throw invalid_argument("Invalid amount.");
                    }

                    account->deposit(amount);
                    break;

                case 4:
                    cout << "Enter account number: ";
                    if (!(cin >> accNo)) {
                        throw invalid_argument("Invalid account number.");
                    }

                    account = findAccount(accounts, accNo);

                    if (account == nullptr) {
                        cout << "Account not found!\n";
                        break;
                    }

                    cout << "Enter withdrawal amount: Rs. ";
                    if (!(cin >> amount)) {
                        throw invalid_argument("Invalid amount.");
                    }

                    account->withdraw(amount);
                    break;

                case 5:
                    cout << "Enter account number: ";
                    if (!(cin >> accNo)) {
                        throw invalid_argument("Invalid account number.");
                    }

                    account = findAccount(accounts, accNo);

                    if (account != nullptr) {
                        account->displayDetails();
                    } else {
                        cout << "Account not found!\n";
                    }
                    break;

                case 6:
                    if (accounts.empty()) {
                        cout << "No accounts available.\n";
                    } else {
                        for (const auto& account : accounts) {
                            account->displayDetails();
                        }
                    }
                    break;

                case 7:
                    cout << "Thank you for using our banking system!\n";
                    break;

                default:
                    cout << "Invalid choice! Try again.\n";
            }
        } catch (const exception& e) {
            cout << "Error: " << e.what() << '\n';
        }

    } while (choice != 7);

    return 0;
}