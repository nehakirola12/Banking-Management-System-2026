#ifndef CURRENTACCOUNT_H
#define CURRENTACCOUNT_H

#include "Account.h"

class CurrentAccount : public Account {
public:
    CurrentAccount(int accNo, const std::string& name, double initialBalance)
        : Account(accNo, name, initialBalance) {
    }

    std::string getAccountType() const override {
        return "Current";
    }

    void withdraw(double amount) override {
        Account::withdraw(amount);
    }
};

#endif