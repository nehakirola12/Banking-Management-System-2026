#include "Account.h"
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <iomanip>

using namespace std;

Account::Account(int accNo, const string& name, double initialBalance) {
    if (accNo <= 0) {
        throw invalid_argument("Account number must be positive.");
    }

    if (name.empty()) {
        throw invalid_argument("Account holder name cannot be empty.");
    }

    if (initialBalance < 0) {
        throw invalid_argument("Initial balance cannot be negative.");
    }

    accountNumber = accNo;
    holderName = name;
    balance = initialBalance;
}

void Account::deposit(double amount) {
    if (amount <= 0) {
        throw invalid_argument("Deposit amount must be positive.");
    }

    balance += amount;

    logTransaction("Deposit", amount);

    cout << "Amount deposited successfully!\n";
}

void Account::withdraw(double amount) {
    if (amount <= 0) {
        throw invalid_argument("Withdrawal amount must be positive.");
    }

    if (amount > balance) {
        throw runtime_error("Insufficient balance!");
    }

    balance -= amount;

    logTransaction("Withdrawal", amount);

    cout << "Amount withdrawn successfully!\n";
}

void Account::displayDetails() const {
    cout << "\n----- Account Details -----\n";
    cout << "Account Number: " << accountNumber << '\n';
    cout << "Account Holder: " << holderName << '\n';
    cout << "Account Type: " << getAccountType() << '\n';
    cout << fixed << setprecision(2);
    cout << "Available Balance: Rs. " << balance << '\n';
}

void Account::saveAccount() const {
    ofstream file("accounts.txt", ios::app);

    if (!file) {
        throw runtime_error("Could not open accounts.txt");
    }

    file << accountNumber << ","
         << holderName << ","
         << getAccountType() << ","
         << fixed << setprecision(2) << balance << '\n';

    if (!file) {
        throw runtime_error("Could not save account details.");
    }
}

void Account::logTransaction(const string& type, double amount) const {
    ofstream file("transactions.txt", ios::app);

    if (!file) {
        throw runtime_error("Could not open transactions.txt");
    }

    file << "Account: " << accountNumber
         << " | Type: " << type
         << " | Amount: " << fixed << setprecision(2) << amount
         << " | Balance: " << balance << '\n';

    if (!file) {
        throw runtime_error("Could not save transaction.");
    }
}

int Account::getAccountNumber() const {
    return accountNumber;
}

double Account::getBalance() const {
    return balance;
}