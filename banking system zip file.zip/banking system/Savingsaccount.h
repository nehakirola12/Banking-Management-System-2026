#ifndef SAVINGSACCOUNT_H
#define SAVINGSACCOUNT_H

#include "Account.h"

class SavingsAccount : public Account {
public:
    SavingsAccount(int accNo, const std::string& name, double initialBalance)
        : Account(accNo, name, initialBalance) {
    }

    std::string getAccountType() const override {
        return "Savings";
    }

    void withdraw(double amount) override {
        Account::withdraw(amount);
    }
};

#endif