# BANKING MANAGEMENT SYSTEM

% Banking Management System Using C++

The Banking Management System is a console-based application developed using C++. It is designed to manage basic banking operations, including creating bank accounts, depositing money, withdrawing money, and displaying account details.
The project uses Object-Oriented Programming (OOP) concepts to organize the program into classes and objects. It also uses file handling to store account information and transaction records in text files.

% Objective
The main objective of this project is to develop a simple banking application that allows users to manage savings and current accounts efficiently.

x The project aims to:
- Provide a simple interface for banking operations.
- Allow users to create savings and current accounts.
- Perform deposit and withdrawal operations.
- Display account information and available balances.
- Prevent withdrawals when the available balance is insufficient.
- Store account and transaction records using file handling.
- Demonstrate important Object-Oriented Programming concepts in C++.

x Programming Language and Tools
- Programming Language: C++
- Compiler: GCC (g++)
- Code Editor: Visual Studio Code
- File Handling: C++ file streams
- Operating System: Windows

% Functional Requirements

! Create Savings Account
The system allows users to create a savings account by entering an account number, account holder's name, and initial balance.

! Create Current Account
The system allows users to create a current account by entering the required account information.

! Deposit Money
Users can deposit money into an existing account. The deposited amount is added to the account balance.

! Withdraw Money
Users can withdraw money from an existing account. The system checks whether the available balance is sufficient before processing the withdrawal.

! Display Account Details
The system displays the account number, account holder's name, account type, and available balance.

! Display All Accounts
Users can display the details of all accounts created during the current program session.

! File Handling
The system stores account records in accounts.txt and transaction records in transactions.txt.

% Object-Oriented Programming Concepts Used

?  Classes and Objects
The Account class represents a bank account. SavingsAccount and CurrentAccount represent specific account types. Objects are created from these classes to perform banking operations.

? Encapsulation
Account information and operations are grouped within classes. The account data members are declared protected so they can be accessed by derived classes while remaining unavailable for direct access from unrelated code.

? Inheritance
SavingsAccount and CurrentAccount inherit common account information and functions from the Account base class. This reduces code duplication and improves code organization.

? Runtime Polymorphism
The Account class declares virtual functions, including getAccountType() and withdraw(). The derived classes override these functions. Virtual function calls through base-class pointers demonstrate runtime polymorphism.

? Constructors
Constructors initialize account information, including the account number, account holder's name, and initial balance.

? Exception Handling
The program uses try, catch, and throw to handle invalid account information, invalid transaction amounts, insufficient balances, and file errors.

?  File Handling
The program uses C++ file streams to save account information and transaction records in text files. The ios::app mode appends new records without overwriting existing records.

% System Workflow
1. The program displays the main menu.
2. The user selects an operation.
3. The user enters the required account information.
4. The system validates the input.
5. The selected operation is performed.
6. Account and transaction records are saved when applicable.
7. The system displays the result.
8. The menu appears again until the user selects Exit.

% File Structure

Banking_Management_System/
- main.cpp
- Account.h
- Account.cpp
- SavingsAccount.h
- CurrentAccount.h
- README.txt
